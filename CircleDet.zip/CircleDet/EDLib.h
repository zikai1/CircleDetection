#pragma once
#ifndef _EDLib_
#define _EDLib_

#include "ED.h"
#include "EDPF.h"
#include "EDColor.h"
#include "RDP.h"
#include"Reject_sharp_turn.h"
#include"DetInflexPt.h"
#include"myTools.h"
#endif